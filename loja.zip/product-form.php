<?php include("header.php");
include("connection.php");
include("storage-category.php");

$categorias = listaCategorias($conexao);
?>
<div class="col-sm-6 col-sm-offset-3">
	<h1>Formulário de produto</h1>
	<form action="add-product.php" method="post">
		<table class="table">
			<tr>
				<td>Nome</td>
				<td><input type="text" class="form-control" name="nome"></td>
			</tr>
			<tr>
				<td>Preço</td>
				<td><input type="number" class="form-control" name="preco"></td>
			</tr>
			<tr>
				<td>Descrição</td>
				<td><textarea name="descricao" class="form-control"></textarea></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="checkbox" name="usado" value="true">Usado</td>
			</tr>
			<tr>
				<td>Categoria</td>
				<td>
					<select  name="categoria_id" class="form-control">
			<?php foreach($categorias as $categoria) : ?>
							<option value="<?=$categoria['id']?>">
							<?=$categoria['nome']?>
						</option>
						<?php endforeach ?>
					</select>
				</td>
			</tr>
		</table>
		<input class="btn btn-primary" type="submit" value="Cadastrar">
	</form>
</div>

<?php include("footer.php");?>