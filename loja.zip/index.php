<?php include("header.php");?>
			<h1>Bem vindo a To'Apps</h1>

<?php include("footer.php");?>