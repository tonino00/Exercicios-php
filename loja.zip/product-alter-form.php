<?php include("header.php");
include("connection.php");
include("storage-category.php");
include("storage.php");

$id = $_GET['id'];
$produto = buscaProduto($conexao, $id);
$categorias = listaCategorias($conexao);
$usado = $produto['usado'] ? "checked='checked'" : "";
?>
<div class="col-sm-6 col-sm-offset-3">
	<h1>Alterar produto</h1>
	<form action="alter-product.php" method="post">
			<input type="hidden" name="id" value="<?=$produto['id']?>">
		<table class="table">
			<tr>
				<td>Nome</td>
				<td><input type="text" class="form-control" name="nome" value="<?=$produto['nome']?>"></td>
			</tr>
			<tr>
				<td>Preço</td>
				<td><input type="number" class="form-control" name="preco" value="<?=$produto['preco']?>"></td>
			</tr>
			<tr>
				<td>Descrição</td>
				<td><textarea  class="form-control" name="descricao"><?=$produto['descricao']?></textarea></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="checkbox" name="usado" <?=$usado?> value="true">Usado</td>
			</tr>
			<tr>
				<td>Categoria</td>
				<td>
					<select  name="categoria_id" class="form-control">
			<?php foreach($categorias as $categoria) : 
			$categoriaTrue = $produto['categoria_id'] == $categoria['id'];
			$codigoSelecao = $categoriaTrue ? "selected='selected'" :"";

			?>
							<option value="<?=$categoria['id']?>" <?=$codigoSelecao?>>
							<?=$categoria['nome']?>
						</option>
						<?php endforeach ?>
					</select>
				</td>
			</tr>
		</table>
		<input class="btn btn-primary" type="submit" value="Alterar">
	</form>
</div>

<?php include("footer.php");?>