<?php  include("header.php"); 
include("storage.php"); 
include("connection.php"); 

$id =$_POST['id'];
removeProduto($conexao, $id);
	
	header("location: product-list.php?removido=true");
	die();
?>

